from KuaiShou.utils.mysql import MySQLClient

# mysql_client = MySQLClient(host='zqhd3', user='tianshu', password='Tianshu_123', dbname='tianshuData')
#
# sql = "select count(*) from kuaishou_scrapy_logs where item_id = '148925262' and is_successed = 1"
# #sql = "select count(*) from kuaishou_scrapy_logs where item_id = '14892526211' and is_successed = 1"
# mysql_client.query(sql)
# d = mysql_client.fetchRow()
# rowCount = d[0]
# print(rowCount)
# print(type(rowCount))
#
# mysql_client.close()


def isCommentIdExistTable(commentId):
    mysql_client = MySQLClient(host='zqhd3', user='tianshu', password='Tianshu_123', dbname='tianshuData')
    sql = "select count(*) from kuaishou_scrapy_logs where item_id = '{}' and is_successed = 1".format(commentId)
    mysql_client.query(sql)
    d = mysql_client.fetchRow()
    rowCount = d[0]
    mysql_client.close()
    if rowCount > 0:
        return True
    else:
        return False

print(isCommentIdExistTable('14892526200'))
