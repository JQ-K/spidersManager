a = [chr(i) for i in range(97, 123)]
b = [str(i) for i in range(10)]
print(a)
print(b)

s = [chr(i) for i in range(97, 123)] + [str(i) for i in range(10)]
print(s)

for i in range(16):
    print(i)

