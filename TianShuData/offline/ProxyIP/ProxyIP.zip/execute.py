#!/usr/bin/env python
# -*- coding:utf-8 -*-
__author__ = 'lish'

from scrapy.cmdline import execute

execute(['scrapy', 'crawl', 'ipyqie_free'])
execute(['scrapy', 'crawl', 'kuaidaili_free'])
execute(['scrapy', 'crawl', 'qydaili_free'])
execute(['scrapy', 'crawl', 'y89ip_free'])
execute(['scrapy', 'crawl', 'ip3366_free'])
execute(['scrapy', 'crawl', 'iphai_free'])
