# -*- coding: utf-8 -*-

account = {
    "百家号": {
        "13656689260": "SHUshuozj2019",
        "战旗高能君": "zswh2019",
    },
    "企鹅号": {
        "2991941540": "Az135246",
    },
    "趣头条": {
        "zjtmkj@8531.cn": "zswh2019",
    },
    "美拍": { #https://www.meipai.com/
        "13918011686": {"password": "123456jj", "userid": "1707115686"},
    },
    "人人": { #https://rr.tv/new/#/sign
        "15802103561": "P@ssword521",
    },
    "搜狗": { #http://mp.sogou.com/
        "shanghaiceno@126.com": "rbe-JrWpY6",
    },
    "浙江新闻": { #http://mcn.8531.cn/
        #"13034656447": "8531test",
        "起航号官方运营号": "zjxw12345",
    },
    "一点资讯": {

    }
}