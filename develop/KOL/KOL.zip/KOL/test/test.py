
'''a = "abc="
parts = a.split("=", 1)
print(parts)

list=["delphi","Delphi","python","Python","c++","C++","c","C","golang","Golang"]
list.sort() #按字典顺序升序排列
print("升序:", list)'''

import time
a = time.time()
print(a)
print(int(a))

