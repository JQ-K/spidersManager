import json
import redis

filepath = 'D:/py_workspace/spidersManager/develop/KOL/KOL/test/kuxuan.txt'
f = open(filepath)

for line in f:
    #print(line)
    srcStr = line.strip()

jsonStr = json.loads(srcStr)

r = redis.Redis(host='10.8.26.105', port=6379, db=1)
redis_id_set_name = "KuaiShouKolId"

for elem in jsonStr:
    id = elem['user_id']
    if r.sismember(redis_id_set_name, id):
        print("id:" + str(id) + " exist...")
        continue
    r.sadd(redis_id_set_name, id)
